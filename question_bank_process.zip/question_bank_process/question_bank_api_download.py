import requests
import json
import time
import os

def read_json_and_jsonl(input_path):
    """
    使用os库的高效JSON/JSONL读取函数
    """
    input_path = os.path.abspath(input_path)
    
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"文件不存在: {input_path}")
    
    _, ext = os.path.splitext(input_path)
    ext = ext.lower()
    
    if ext == ".json":
        with open(input_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        print(f"读取JSON文件: {input_path}, 数据量: {len(data) if isinstance(data, list) else '非列表结构'}")
        return data
    
    elif ext == ".jsonl":
        data = []
        with open(input_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            if not line:
                continue
            try:
                data.append(json.loads(line))
            except json.JSONDecodeError:
                print(f"警告: 行 {line_num} 解析失败，已跳过")
                continue
        
        print(f"读取JSONL文件: {input_path}, 有效数据量: {len(data)}/{len(lines)}")
        return data
    elif ext == ".txt":
        with open(input_path, "r", encoding="utf-8") as f:
            data = [line.strip() for line in f if line.strip()]
        print(f"读取TXT文件: {input_path}, 数据量: {len(data)}")
        return data
    else:
        raise ValueError(f"不支持的文件格式: {ext}，仅支持.json和.jsonl")


def write_json_and_jsonl(data, output_path):
    """
    使用os库的高效JSON/JSONL写入函数
    """
    output_path = os.path.abspath(output_path)
    output_dir = os.path.dirname(output_path)
    os.makedirs(output_dir, exist_ok=True)
    
    _, ext = os.path.splitext(output_path)
    ext = ext.lower()
    
    if ext == ".json":
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        print(f"写入JSON文件: {output_path}, 数据量: {len(data) if isinstance(data, list) else '非列表结构'}")
    
    elif ext == ".jsonl":
        lines = [json.dumps(item, ensure_ascii=False) + "\n" for item in data]
        with open(output_path, "w", encoding="utf-8") as f:
            f.writelines(lines)
        print(f"写入JSONL文件: {output_path}, 数据量: {len(data)}")
    
    else:
        raise ValueError(f"不支持的文件格式: {ext}，仅支持.json和.jsonl")

# 配置接口信息
API_URL = 'http://gateway.staff.xdf.cn/k12-tiku-open-api/api/question/v2/infos'
BASE_HEADERS = {
    'timestamp': '1742279280546',  
    'appCode': '9JDJiPTuTKq0UjJo57juBoHVUPxCDRd4',
    'appToken': '3A482367DB883B02710F6398A849F3DC',
    'businessCode': 'bl5FJUemwNmveh3hKnPCzH23PWrqYCRA',
    'Content-Type': 'application/json'
}

def download_questions_to_jsonl(id_list, output_path, batch_size=10):
    """
    批量下载题目信息并保存为 jsonl 文件（支持断点续传）。
    """
    
    # 1. 准备输出目录
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
        
    # ================= 新增：断点续传逻辑 =================
    downloaded_ids = set()
    if os.path.exists(output_path):
        print("检测到已有输出文件，正在读取已下载的题目ID...")
        with open(output_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    item = json.loads(line)
                    # 尝试获取题目ID（适配常见的 id 或 questionId 字段）
                    qid = str(item.get('questionId'))
                    if qid and qid != 'None':
                        downloaded_ids.add(qid)
                except json.JSONDecodeError:
                    continue
                    
    # 过滤掉已经下载过的ID
    original_count = len(id_list)
    id_list = [str(qid) for qid in id_list if str(qid) not in downloaded_ids]
    
    print(f"=== 任务概览 ===")
    print(f"总计ID数量: {original_count}")
    print(f"已下载数量: {len(downloaded_ids)}")
    print(f"本次需下载: {len(id_list)}")
    print(f"BatchSize: {batch_size}")
    print(f"================")

    if not id_list:
        print("所有题目均已下载完毕，无需执行请求。")
        return
    # ======================================================

    total_count = len(id_list)

    # 2. 循环分批处理
    for i in range(0, total_count, batch_size):
        batch_ids = id_list[i : i + batch_size]
        current_progress = min(i + batch_size, total_count)
        
        print(f"[{current_progress}/{total_count}] 正在请求...")

        headers = BASE_HEADERS.copy()
        payload = {
            "questionIdList": [{"questionId": str(qid)} for qid in batch_ids]
        }

        try:
            response = requests.post(API_URL, headers=headers, json=payload, timeout=15)
            response.raise_for_status() 
            
            result_json = response.json()
            
            if result_json.get('success') is True and result_json.get('code') == 200:
                data_list = result_json.get('data')
                
                if data_list:
                    # 注意：这里必须用 'a' (追加模式)，不能用 'w'，否则会覆盖之前的文件
                    with open(output_path, 'a', encoding='utf-8') as f:
                        for item in data_list:
                            f.write(json.dumps(item, ensure_ascii=False) + '\n')
                else:
                    print(f"  -> 警告: 接口返回成功，但 'data' 为空。批次ID: {batch_ids}")
            else:
                print(f"  -> 错误: 接口业务逻辑失败. Message: {result_json.get('message')}")

        except requests.exceptions.RequestException as e:
            print(f"  -> 网络请求异常: {e}")
        except json.JSONDecodeError:
            print(f"  -> 解析返回 JSON 失败")
        except Exception as e:
            print(f"  -> 未知错误: {e}")

        time.sleep(0.2)

    print(f"\n=== 处理完成！数据已保存至: {output_path} ===")

def download_questions():
    input_path = r"D:\0_work\llm\项目文件\物理知识点打标\src\test_api\check\physics_test_dataset_2026_07_09.jsonl"
    
    data = read_json_and_jsonl(input_path)
    my_question_ids = [item['parent_id'] for item in data if 'parent_id' in item]
    
    output_path = r"D:\0_work\llm\项目文件\物理知识点打标\src\test_api\check\physics_test_dataset_tiku_api_wodnload.jsonl"


    download_questions_to_jsonl(
        id_list=my_question_ids, 
        output_path=output_path, 
        batch_size=20
    )
    

    
       
if __name__ == "__main__":
    download_questions()
